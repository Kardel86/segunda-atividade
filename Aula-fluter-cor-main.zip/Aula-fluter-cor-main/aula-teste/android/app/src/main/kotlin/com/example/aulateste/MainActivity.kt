package com.example.aulateste

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
